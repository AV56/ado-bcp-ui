export enum ScreenId {
  WELCOME_SCREEN = 'Welcome to Storage',
}
