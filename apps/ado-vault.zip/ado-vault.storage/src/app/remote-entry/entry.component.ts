import { Component } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-ado-vault.storage-entry',
  template: `<ado-bcp-ui-storage></ado-bcp-ui-storage>`,
})
export class RemoteEntryComponent {}
