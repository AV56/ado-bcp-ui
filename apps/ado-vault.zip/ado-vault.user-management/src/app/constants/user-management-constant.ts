export enum ScreenId {
  WELCOME_SCREEN = 'Welcome to User Management',
}
