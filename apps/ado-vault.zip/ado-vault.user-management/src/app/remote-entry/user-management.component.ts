import { Component, ViewEncapsulation } from '@angular/core';
import { ScreenId } from '../constants/user-management-constant';

/* eslint-disable */

@Component({
  selector: 'ado-bcp-ui-nx-user-management',
  template: `<ado-bcp-ui-sidebar></ado-bcp-ui-sidebar>
             <ado-bcp-ui-header></ado-bcp-ui-header>
             <ado-bcp-ui-table from="{{ show }}"></ado-bcp-ui-table>`,
  styles: [],
  encapsulation: ViewEncapsulation.None,
})
export class UserManagementComponent {
  show: any;
  constructor() {
    this.show = ScreenId.WELCOME_SCREEN;
  }
}
