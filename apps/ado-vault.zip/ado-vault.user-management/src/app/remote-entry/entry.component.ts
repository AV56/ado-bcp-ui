import { Component } from '@angular/core';

@Component({
  selector: 'ado-bcp-ui-ado-vault.user-management-entry',
  template: `<ado-bcp-ui-nx-user-management></ado-bcp-ui-nx-user-management>`,
})
export class RemoteEntryComponent {}
